// Define the 'HaveASeat' module
angular.module('HaveASeat', [
  'ngRoute',
  'header',
  'restaurants',
  'seats',
  'index',
  'login',
  'signup',
  'admin',
  'welcomeheader',
  'adminheader',
  'logout',
  'home'
]);
